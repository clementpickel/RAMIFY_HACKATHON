import numpy as np
from collections import deque

p = {'A': deque(maxlen=100), 'B': deque(maxlen=100)}

def make_decision(epoch, priceA, priceB):
    p['A'].append(priceA)
    p['B'].append(priceB)
    if len(p['A']) < 30: return {'Asset A': 0.0, 'Asset B': 0.0, 'Cash': 1.0}
    
    scores = {}
    for asset, prices in [('A', p['A']), ('B', p['B'])]:
        arr = np.array(prices)
        ret = np.diff(arr) / arr[:-1]
        vol = max(np.std(ret[-20:]), 0.001)
        
        m5 = (arr[-1] / arr[-6] - 1) / (vol * 2.236)
        m10 = (arr[-1] / arr[-11] - 1) / (vol * 3.162)
        m20 = (arr[-1] / arr[-21] - 1) / (vol * 4.472)
        signal = 0.5 * m5 + 0.3 * m10 + 0.2 * m20
        
        change = abs(arr[-1] - arr[-11])
        path = sum(abs(np.diff(arr[-11:])))
        er = change / path if path > 0 else 0
        
        scores[asset] = signal * er
    
    best = max(scores, key=scores.get)
    if scores[best] > 0.07:
        return {'Asset A': 1.0 if best == 'A' else 0.0, 
                'Asset B': 1.0 if best == 'B' else 0.0, 
                'Cash': 0.0}
    return {'Asset A': 0.0, 'Asset B': 0.0, 'Cash': 1.0}


